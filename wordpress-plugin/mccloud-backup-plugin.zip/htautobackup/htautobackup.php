<?php
/*
    Plugin Name: Heaventree Auto Backup
    Description: Backup WordPress site (themes, plugins, uploads, DB, wp-config) and upload to Dropbox.
    Version: 1.0.1
    Author: Heaventree
*/
if (!defined('ABSPATH'))
    exit;

require_once plugin_dir_path( __FILE__ ) . 'Crud.php';
require 'vendor/autoload.php';

@set_time_limit(0);
@ignore_user_abort(true);


use ZipStream\ZipStream;
use ZipStream\Option\Archive;
use ZipStream\Option\File as FileOptions;
use ZipStream\Option\Method;

register_activation_hook( __FILE__, 'ht_autobackup_create_database' );
register_deactivation_hook( __FILE__, 'ht_autobackup_remove_database' );

add_action('rest_api_init', function () {
    register_rest_route('backsheep/v1', '/backup/start', [
        'methods' => 'POST',
        'callback' => 'backsheep_start_backup',
        'permission_callback' => '__return_true'
    ]);

    register_rest_route('backsheep/v1', '/backup/run', [
        'methods' => 'POST',
        'callback' => 'backsheep_run_backup',
        'permission_callback' => '__return_true'
    ]);

    register_rest_route('backsheep/v1', '/backup/status', [
        'methods' => 'POST',
        'callback' => 'backsheep_check_backup_status',
        'permission_callback' => '__return_true'
    ]);

    register_rest_route('backsheep/v1', '/backup/status/log', [
        'methods' => 'POST',
        'callback' => 'backsheep_check_backup_log',
        'permission_callback' => '__return_true'
    ]);

    ## NEW APIS ##
    register_rest_route('backsheep/v1', '/backup/prepare', [
        'methods' => 'POST',
        'callback' => 'backsheep_prepare_endpoint', 
        'permission_callback' => '__return_true'
    ]);

    register_rest_route('backsheep/v1', '/backup/upload', [
        'methods' => 'POST',
        'callback' => 'backsheep_upload_endpoint',  
        'permission_callback' => '__return_true'
    ]);

    register_rest_route('backsheep/v1', '/backup/verify', [
        'methods' => 'POST',
        'callback' => 'backsheep_verify_endpoint',  
        'permission_callback' => '__return_true'
    ]);

    register_rest_route('backsheep/v1', '/backup/clean', [
        'methods' => 'POST',
        'callback' => 'backsheep_clean_endpoint',   
        'permission_callback' => '__return_true'
    ]);
});

add_action('backsheep_do_backup', 'backsheep_prepare_backup', 10, 4);
add_action('admin_init', 'ht_autobackup_settings_init');
add_action('admin_menu', 'ht_autobackup_add_admin_menu');
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'ht_autobackup_add_settings_link');

function ht_autobackup_create_database() {
    global $wpdb;

    $table_name = $wpdb->prefix . 'htautobackup_log';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        process_id varchar(255) NOT NULL,
        state varchar(255) NOT NULL,
        status varchar(255) NOT NULL,
        message text DEFAULT NULL,
        time_stamp varchar(255) DEFAULT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta( $sql );
}

function ht_autobackup_remove_database() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'htautobackup_log';
    $wpdb->query( "DROP TABLE IF EXISTS $table_name" );
}

function ht_autobackup_settings_init() {
    register_setting('ht_autobackup_settings_group', 'ht_autobackup_webhook');
    register_setting('ht_autobackup_settings_group', 'ht_autobackup_token');
    add_settings_section(
        'ht_autobackup_section',
        'HT Autobackup Settings',
        null,
        'htautobackup'
    );
    add_settings_field(
        'ht_autobackup_webhook_field',
        'Webhook URL',
        'ht_autobackup_webhook_field_render',
        'htautobackup',
        'ht_autobackup_section'
    );
    add_settings_field(
        'ht_autobackup_token_field',
        'Backup Token',
        'ht_autobackup_token_field_render',
        'htautobackup',
        'ht_autobackup_section'
    );
}

function ht_autobackup_webhook_field_render() {
    $value = get_option('ht_autobackup_webhook');
    echo '<input type="url" name="ht_autobackup_webhook" value="' . esc_attr($value) . '" size="50" />';
}

function ht_autobackup_token_field_render() {
    $value = get_option('ht_autobackup_token');
    echo '<input type="password" name="ht_autobackup_token" value="' . esc_attr($value) . '" />';
}

function ht_autobackup_add_admin_menu() {
    add_submenu_page(
        null,
        'HT Autobackup Settings',
        'HT Autobackup Settings',
        'manage_options',
        'htautobackup',
        'ht_autobackup_settings_page'
    );
}

function ht_autobackup_settings_page() {
    ?>
    <div class="wrap">
        <form method="post" action="options.php">
            <?php
                settings_fields('ht_autobackup_settings_group');
                do_settings_sections('htautobackup');
                submit_button('Save Settings');
            ?>
        </form>
    </div>
    <?php
}

function ht_autobackup_add_settings_link($links) {
    $settings_link = '<a href="' . admin_url('admin.php?page=htautobackup') . '">Settings</a>';
    array_unshift($links, $settings_link);
    return $links;
}

function backsheep_start_backup(WP_REST_Request $request)
{
    
    $process_id = uniqid('ht_', true);
    $base_dir = plugin_dir_path(__FILE__);
    $tmp_dir = $base_dir . 'tmp/';
    $process_dir = $tmp_dir . $process_id;

    if (!file_exists($tmp_dir)) {
        mkdir($tmp_dir, 0777, true);
    }

    mkdir($process_dir, 0777, true);
    $site_domain = parse_url(get_site_url(), PHP_URL_HOST);

    $timestamp = date('Y-m-d_H-i-s');
    $dropbox_path = "/MCCLOUD - BACKUPS/{$site_domain}/{$timestamp}/";

    backsheep_update_status($process_id, 1 , "PROCESS_CREATED", 'Process created successfully!' , $timestamp);

    return new WP_REST_Response(['status' => "SUCCESS", 'state' =>"PROCESS_CREATED", "message" => "Backup process created successfully!", 'process_id' => $process_id ,'path' => $dropbox_path, 'token'=> get_option('ht_autobackup_token')]);
}

function backsheep_run_backup(WP_REST_Request $request){
    $crud = new CRUD();

    $process_id = $request->get_param('process_id');
    $dropbox_token = $request->get_param('dropbox_token');
    $mode = $request->get_param('mode') ?? "ALL";

    if (!$process_id || !htautobackup_validate_process_id($process_id)) {
        return new WP_REST_Response(['status'=> "ERROR", 'state'=>"MISSING_PROCESS_ID", 'message' => 'Missing or invalid process_id'], 400);
    }
    if (!$dropbox_token) {
        return new WP_REST_Response(['status'=> "ERROR", 'state'=>"MISSING_TOKEN", 'message' => 'Missing Dropbox token'], 400);
    }

    $process = $crud->get_row("SELECT * FROM `{$crud->log_table()}` WHERE process_id='$process_id' ORDER BY id ASC LIMIT 1");

    if (!$process) {
        return new WP_REST_Response(['status'=> "ERROR", 'state'=>"INVALID_PROCESS_ID", 'message' => 'Invalid process_id'], 404);
    }

    $base_dir = plugin_dir_path(__FILE__);
    $tmp_dir = $base_dir . 'tmp/';
    $process_dir = $tmp_dir . $process_id;

    $response = new WP_REST_Response([
        'status' => 'SUCCESS',
        'state'=>"PROCESS_RUNNING",
        'message' => 'Backup process running'
    ]);
    $response->set_status(200);
    
    @ob_end_clean();
    header('Connection: close');
    ob_start();
    echo json_encode($response->get_data());
    $size = ob_get_length();
    header("Content-Length: $size");
    ob_end_flush();
    flush();
    
    if (isset($process['state']) && in_array($process['state'], ["PROCESS_CREATED", "MISSING_PROCESS_ID", "MISSING_TOKEN"])) {
        backsheep_prepare_backup($dropbox_token, $process_id, $process_dir, $mode);
    }
}

function backsheep_check_backup_status(WP_REST_Request $request)
{
    $process_id = $request->get_param('process_id');
    if (!$process_id || !htautobackup_validate_process_id($process_id)) {
        return new WP_REST_Response(['status'=> "ERROR", 'state'=>"MISSING_PROCESS_ID", 'message' => 'Missing or invalid process_id'], 400);
    }
    
    $crud = new Crud();
    $process = $crud->get_row("SELECT * FROM `{$crud->log_table()}` WHERE process_id='$process_id' ORDER BY id DESC LIMIT 1");

    if ( !$process || empty($process)) {
        return new WP_REST_Response(['status'=> "ERROR", 'state'=>"INVALID_PROCESS_ID", 'message' => 'Invalid process_id'], 404);
    }
    $statuses = [0 => "ERROR", 1 => "SUCCESS"];
    $site_domain = parse_url(get_site_url(), PHP_URL_HOST);
    $timestamp = get_process_created_timestamp($process_id);
    $dropbox_path = "/MCCLOUD - BACKUPS/{$site_domain}/{$timestamp}/";

    $status = [
        'process_id'=>$statuses[$process['status']] ?? "UNKNOWN",
        'state'=>$process['state'],
        'progress' => $process['message'],
        'path' => $dropbox_path
    ];
    return new WP_REST_Response($status);
}

function backsheep_check_backup_log(WP_REST_Request $request)
{
    $process_id = $request->get_param('process_id');
    if (!$process_id || !htautobackup_validate_process_id($process_id)) {
        send_fail_process_webhook($process_id, "MISSING_PROCESS_ID");
        return new WP_REST_Response([
            'status' => "ERROR",
            'state' => "MISSING_PROCESS_ID",
            'message' => 'Missing or invalid process_id'
        ], 400);
    }

    $crud = new Crud();
    $log = $crud->get_data("SELECT * FROM `{$crud->log_table()}` WHERE process_id='$process_id' ORDER BY id ASC ");
    if (empty($log)) {
        send_fail_process_webhook($process_id, "INVALID_PROCESS_ID");
        return new WP_REST_Response([
            'status' => "ERROR",
            'state' => "INVALID_PROCESS_ID",
            'message' => 'Invalid process_id'
        ], 404);
    }
    $prepared = [];
    foreach ($log as $entry) {
        $key = date('Y-m-d_H-i-s', strtotime($entry['created_at']));
        switch($entry['status']){
            case 1:
                $status = "SUCCESS";
                break;
            case 0:
                $status = "ERROR";
                break;
            default:
                $status = "UNKNOWN";
        }
        $prepared[$key] = [
            'status' => $status,
            'state' => $entry['state'],
            'message' => $entry['message'],
        ];
    }

    return new WP_REST_Response([
        'status' => "SUCCESS",
        'state' => "LOG_LOADED",
        'message' => 'Log loaded successfully',
        'log' => $prepared
    ]);
}

function backsheep_update_status($process_id, $status, $state, $message , $timestamp = NULL)
{
    $crud = new Crud();
    if($status == "SUCCESS"){
        $status = 1;
    }elseif($status == "ERROR"){
        $status = 0;
    }
    $insert = "INSERT INTO `{$crud->log_table()}`(`process_id`, `state`, `status`, `message`, `time_stamp`) VALUES ('$process_id','$state','$status','$message','$timestamp')";
    $crud->execute($insert);
    snooze();
}

function backsheep_update_process_status($process_id, $state, $message) 
{
    $crud = new Crud();

    $row = $crud->get_row("SELECT id FROM {$crud->log_table()} WHERE process_id = '".$process_id."' AND state = '".$state."' ORDER BY id DESC LIMIT 1");

    if ($row['id']) {
        $crud->update($crud->log_table(),[ 'message' => $message ],[ 'id' => $row['id'] ],[ '%s' ],[ '%d' ]);
    }
}



function backsheep_prepare_backup($dropbox_token, $process_id, $backup_dir , $mode = "ALL")
{
    @set_time_limit(0);
    @ignore_user_abort(true);
    
    try {
        $backup = [];
        
        $timestamp = get_process_created_timestamp($process_id);
        $verify_token = verify_token($dropbox_token, $timestamp);
        
        if($verify_token['status'] == "ERROR"){
            throw new Exception(json_encode($verify_token));
        }else{
            backsheep_update_status($process_id, $verify_token['status'], $verify_token['state'], $verify_token['message']);
        }
        backsheep_update_status($process_id, 'SUCCESS', "FILE_SCANNING" , "Scanning the files for backup");
        
        if($mode == "DB"){
            $backup = ["database.sql"];
        }
        elseif($mode == "THEME"){
            $backup = ["themes.zip"];
        }
        elseif($mode == "PLUGIN"){
            $backup = ["plugins.zip"];
        }
        elseif($mode == "FILE"){
            $backup = ["wp-config.php", ".htaccess", "themes.zip", "plugins.zip"];
        }
        else {
            $backup = ["database.sql", "wp-config.php", ".htaccess", "themes.zip", "plugins.zip"];
        }
        
        $first_file = $backup[0];
        $remaining = array_slice($backup, 1);
        
        $payload = [
            'process_id'    => $process_id,
            'dropbox_token' => $dropbox_token,
            'backup_dir'    => $backup_dir,
            'file'          => $first_file,
            'remaining'     => $remaining,
            'all_files'     => $backup
        ];

        wp_remote_post(
            rest_url('backsheep/v1/backup/prepare'),
            [
                'method'    => 'POST',
                'blocking'  => false,
                'headers'   => ['Content-Type' => 'application/json'],
                'body'      => json_encode($payload),
                'timeout'   => 0.1
            ]
        );
        
    } catch (Exception $e) {
        $error = json_decode($e->getMessage(), true);
        send_fail_process_webhook($process_id, $error['status'], $error['message']);
        backsheep_update_status($process_id, $error['status'], $error['state'], $error['message']);
    }
}

function backsheep_normalize_array_param($val) {
    if (is_null($val)) return [];
    if (is_array($val)) return $val;
    // string: maybe JSON encoded or comma-separated
    if (is_string($val)) {
        $dec = json_decode($val, true);
        if (is_array($dec)) return $dec;
        // fallback: comma separated
        return array_filter(array_map('trim', explode(',', $val)), fn($v) => $v !== '');
    }
    return [];
}

/**
 * PREPARE endpoint: prepares one file (db dump / copy / create zip) and chains to next prepare or upload start.
 */
function backsheep_prepare_endpoint(WP_REST_Request $request) {
    $params = $request->get_json_params();
    if (empty($params)) $params = $request->get_params();

    $process_id = sanitize_text_field($params['process_id'] ?? '');
    $backup_dir = $params['backup_dir'] ?? '';
    $dropbox_token = $params['dropbox_token'] ?? '';
    $file = $params['file'] ?? '';
    $remaining = backsheep_normalize_array_param($params['remaining'] ?? []);
    $all_files = backsheep_normalize_array_param($params['all_files'] ?? []);

    if (!$process_id || !$backup_dir || !$file || !htautobackup_validate_process_id($process_id)) {
        return new WP_REST_Response(['status'=>'ERROR','state'=>'FILE_SCANNING','message'=>'Invalid request'], 400);
    }

    $process_dir = rtrim($backup_dir, DIRECTORY_SEPARATOR);

    try {
        if (!file_exists($process_dir)) {
            mkdir($process_dir, 0777, true);
        }

        if ($file === 'database.sql') {
            global $wpdb;
            $tables = $wpdb->get_col("SHOW TABLES");
            $count = count($tables);

            backsheep_update_status($process_id, 'SUCCESS', "BACKUP_DATABASE", "Backing Up " . $count . " tables");

            $db_file = $process_dir . DIRECTORY_SEPARATOR . 'database.sql';
            file_put_contents($db_file, "-- WordPress Database Backup\n\n");
            file_put_contents($db_file, "SET FOREIGN_KEY_CHECKS=0;\n\n", FILE_APPEND);

            $i = 1;
            foreach ($tables as $table) {
                snooze();

                $create_table = $wpdb->get_row("SHOW CREATE TABLE `$table`", ARRAY_N);
                $auto_inc = $wpdb->get_var(" SELECT AUTO_INCREMENT FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = '$table' ");

                $structure  = "\n\n-- `$table`\n";

                if ($auto_inc) {
                    $sql = preg_replace( '/\)\s*ENGINE=/i', ") ENGINE=InnoDB AUTO_INCREMENT=$auto_inc ", $create_table[1] );
                    $structure .= $sql . ";\n\n";
                } else {
                    $structure .= $create_table[1] . ";\n\n";
                }

                file_put_contents($db_file, $structure, FILE_APPEND);

                $limit  = 500;
                $offset = 0;
                do {
                    $rows = $wpdb->get_results("SELECT * FROM `$table` LIMIT $offset, $limit", ARRAY_A);

                    if (!empty($rows)) {
                        $columns = array_map(fn($col) => '`' . str_replace("`", "``", $col) . '`', array_keys($rows[0]));

                        $insert_sql = "INSERT INTO `$table` (" . implode(", ", $columns) . ") VALUES \n";

                        $value_sets = [];
                        foreach ($rows as $row) {
                            $values  = array_map(function ($val) {
                                if ($val === null) return 'NULL';
                                return "'" . addslashes($val) . "'";
                            }, array_values($row));
                            $value_sets[] = "(" . implode(", ", $values) . ")";
                        }

                        $insert_sql .= implode(",\n", $value_sets) . ";\n";
                        file_put_contents($db_file, $insert_sql, FILE_APPEND);
                    }

                    $offset += $limit;
                } while (!empty($rows));

                $message = $i . "/" . $count . " table's backup completed successfully";
                backsheep_update_process_status($process_id, "BACKUP_DATABASE", $message);
                $i++;
            }

            file_put_contents($db_file, "\nSET FOREIGN_KEY_CHECKS=1;\n", FILE_APPEND);
            backsheep_update_status($process_id, 'SUCCESS', 'BACKUP_DATABASE', "database backup prepared");
        }
        elseif ($file === 'wp-config.php' || $file === '.htaccess') {
            backsheep_update_status($process_id, 'SUCCESS', 'BACKUP_FILES', "Backing up $file");
            $src = ABSPATH . $file;
            $dest = $process_dir . DIRECTORY_SEPARATOR . basename($file);
            if (file_exists($src)) {
                if (!copy($src, $dest)) {
                    throw new Exception("Failed to copy $file");
                }
                backsheep_update_status($process_id, 'SUCCESS', 'BACKUP_FILES', "$file prepared for backup");
            } else {
                backsheep_update_status($process_id, 'SUCCESS', 'BACKUP_FILES', "$file not found, skipping");
            }

        } elseif ($file === 'themes.zip') {
            backsheep_update_status($process_id, 'SUCCESS', 'BACKUP_FILES', "Backing up Themes");
            $theme_dir = normalize_and_escape_path(get_theme_root());
            $r = create_zip($theme_dir, $process_dir, 'themes');
            if (!$r['success']) {
                throw new Exception($r['message']);
            }
            backsheep_update_status($process_id, 'SUCCESS', 'BACKUP_FILES', "Backup prepared for Themes");
            
        } elseif ($file === 'plugins.zip') {
            backsheep_update_status($process_id, 'SUCCESS', 'BACKUP_FILES', "Backing up Plugins");

            $plugin_dir = normalize_and_escape_path(WP_PLUGIN_DIR);
            $current_plugin_slug = basename(dirname(__FILE__));

            // Exclude path should be prefixed with "plugins/"
            $exclude = ['plugins/' . $current_plugin_slug];

            $r = create_zip($plugin_dir, $process_dir, 'plugins', $exclude);

            if (!$r['success']) {
                throw new Exception($r['message']);
            }

            backsheep_update_status($process_id, 'SUCCESS', 'BACKUP_FILES', "Backup prepared for Plugins");
        }
        else {
            backsheep_update_status($process_id, 'SUCCESS', 'BACKUP_FILES', "Unknown file: $file (skipped)");
        }

        if (!empty($remaining)) {
            $next_file = array_shift($remaining);
            $payload = [
                'process_id'    => $process_id,
                'dropbox_token' => $dropbox_token,
                'backup_dir'    => $backup_dir,
                'file'          => $next_file,
                'remaining'     => $remaining,
                'all_files'     => $all_files
            ];
            wp_remote_post(rest_url('backsheep/v1/backup/prepare'), [
                'method'    => 'POST',
                'blocking'  => false,
                'headers'   => ['Content-Type' => 'application/json'],
                'body'      => json_encode($payload),
                'timeout'   => 0
            ]);
        } else {
            $first_upload = $all_files[0] ?? $file;
            $upload_remaining = array_slice($all_files, 1);
            $payload = [
                'process_id'    => $process_id,
                'dropbox_token' => $dropbox_token,
                'backup_dir'    => $backup_dir,
                'file'          => $first_upload,
                'remaining'     => $upload_remaining,
                'all_files'     => $all_files
            ];
            backsheep_update_status($process_id, 'SUCCESS', 'BACKUP_FILES', 'Preparing files for upload');
            wp_remote_post(rest_url('backsheep/v1/backup/upload'), [
                'method'    => 'POST',
                'blocking'  => false,
                'headers'   => ['Content-Type' => 'application/json'],
                'body'      => json_encode($payload),
                'timeout'   => 0
            ]);
        }

        return new WP_REST_Response(['status'=>'SUCCESS','state'=>'BACKUP_FILES','message'=>"$file prepared"], 200);

    } catch (Exception $e) {
        $error = json_decode($e->getMessage(), true);
        send_fail_process_webhook($process_id, $error['status'], $error['message']);
        backsheep_update_status($process_id, $error['status'], $error['state'], $error['message']);
        return new WP_REST_Response(['status'=>'ERROR','state'=>'BACKUP_FILES','message'=>$error['message']], 500);
    }
}

/**
 * UPLOAD endpoint: uploads one file then chains next upload or starts verify-phase.
 */
function backsheep_upload_endpoint(WP_REST_Request $request) {
    $params = $request->get_json_params();
    if (empty($params)) $params = $request->get_params();

    $process_id = sanitize_text_field($params['process_id'] ?? '');
    $backup_dir = $params['backup_dir'] ?? '';
    $dropbox_token = $params['dropbox_token'] ?? '';
    $file = $params['file'] ?? '';
    $remaining = backsheep_normalize_array_param($params['remaining'] ?? []);
    $all_files = backsheep_normalize_array_param($params['all_files'] ?? []);

    if (!$process_id || !$backup_dir || !$file || !htautobackup_validate_process_id($process_id)) {
        return new WP_REST_Response(['status'=>'ERROR','state'=>'BACKUP_UPLOAD','message'=>'process_id, backup_dir and file are required'], 400);
    }

    $process_dir = rtrim($backup_dir, DIRECTORY_SEPARATOR);
    $file_path = $process_dir . DIRECTORY_SEPARATOR . $file;

    try {
        backsheep_update_status($process_id, 'SUCCESS', 'BACKUP_UPLOAD', "Uploading $file");

        if (!file_exists($file_path)) {
            throw new Exception("File not found for upload: $file_path");
        }

        $timestamp = get_process_created_timestamp($process_id);
        $result = upload_to_dropbox($file_path, $dropbox_token, $timestamp);

        if (!$result['success']) {
            throw new Exception($result['message']);
        }

        backsheep_update_status($process_id, 'SUCCESS', 'BACKUP_UPLOAD', "$file uploaded to Dropbox");

        if (!empty($remaining)) {
            $next_file = array_shift($remaining);
            $payload = [
                'process_id'    => $process_id,
                'dropbox_token' => $dropbox_token,
                'backup_dir'    => $backup_dir,
                'file'          => $next_file,
                'remaining'     => $remaining,
                'all_files'     => $all_files
            ];
            wp_remote_post(rest_url('backsheep/v1/backup/upload'), [
                'method'    => 'POST',
                'blocking'  => false,
                'headers'   => ['Content-Type' => 'application/json'],
                'body'      => json_encode($payload),
                'timeout'   => 0.1
            ]);
        } else {
            $first_verify = $all_files[0] ?? $file;
            $verify_remaining = array_slice($all_files, 1);
            $payload = [
                'process_id'    => $process_id,
                'dropbox_token' => $dropbox_token,
                'backup_dir'    => $backup_dir,
                'file'          => $first_verify,
                'remaining'     => $verify_remaining,
                'all_files'     => $all_files
            ];
            backsheep_update_status($process_id, 'SUCCESS', 'BACKUP_UPLOAD', 'Upload backups completed');
            wp_remote_post(rest_url('backsheep/v1/backup/verify'), [
                'method'    => 'POST',
                'blocking'  => false,
                'headers'   => ['Content-Type' => 'application/json'],
                'body'      => json_encode($payload),
                'timeout'   => 0.1
            ]);
        }

        return new WP_REST_Response(['status'=>'SUCCESS','state'=>'BACKUP_UPLOAD','message'=>"$file uploaded"], 200);
    } catch (Exception $e) {
        $msg = $e->getMessage();
        backsheep_update_status($process_id, 'ERROR', 'BACKUP_UPLOAD', $msg);
        send_fail_process_webhook($process_id, 'BACKUP_UPLOAD', $msg);
        return new WP_REST_Response(['status'=>'ERROR','state'=>'BACKUP_UPLOAD','message'=>$msg], 500);
    }
}

/**
 * VERIFY endpoint: verifies a single file on Dropbox and chains to next verify or clean-phase.
 */
function backsheep_verify_endpoint(WP_REST_Request $request) {
    $params = $request->get_json_params();
    if (empty($params)) $params = $request->get_params();

    $process_id = sanitize_text_field($params['process_id'] ?? '');
    $backup_dir = $params['backup_dir'] ?? '';
    $dropbox_token = $params['dropbox_token'] ?? '';
    $file = $params['file'] ?? '';
    $remaining = backsheep_normalize_array_param($params['remaining'] ?? []);
    $all_files = backsheep_normalize_array_param($params['all_files'] ?? []);

    if (!$process_id || !$backup_dir || !$file || !htautobackup_validate_process_id($process_id)) {
        return new WP_REST_Response(['status'=>'ERROR','state'=>'VERIFY_UPLOAD','message'=>'process_id, backup_dir and file are required'], 400);
    }

    $process_dir = rtrim($backup_dir, DIRECTORY_SEPARATOR);
    $file_path = $process_dir . DIRECTORY_SEPARATOR . $file;

    try {
        backsheep_update_status($process_id, 'SUCCESS', 'VERIFY_UPLOAD', "Verifying $file");

        $timestamp = get_process_created_timestamp($process_id);
        $result = verify_uploads($file_path, $dropbox_token, $timestamp);

        if (!$result['success']) {
            throw new Exception($result['message']);
        }

        backsheep_update_status($process_id, 'SUCCESS', 'VERIFY_UPLOAD', "$file verified successfully");

        if (!empty($remaining)) {
            $next_file = array_shift($remaining);
            $payload = [
                'process_id'    => $process_id,
                'dropbox_token' => $dropbox_token,
                'backup_dir'    => $backup_dir,
                'file'          => $next_file,
                'remaining'     => $remaining,
                'all_files'     => $all_files
            ];
            wp_remote_post(rest_url('backsheep/v1/backup/verify'), [
                'method'    => 'POST',
                'blocking'  => false,
                'headers'   => ['Content-Type' => 'application/json'],
                'body'      => json_encode($payload),
                'timeout'   => 0.1
            ]);
        } else {
            $first_clean = $all_files[0] ?? $file;
            $clean_remaining = array_slice($all_files, 1);
            $payload = [
                'process_id'    => $process_id,
                'dropbox_token' => $dropbox_token,
                'backup_dir'    => $backup_dir,
                'file'          => $first_clean,
                'remaining'     => $clean_remaining,
                'all_files'     => $all_files
            ];
            backsheep_update_status($process_id, 'SUCCESS', 'VERIFY_UPLOAD', 'Verification phase completed - starting cleaning temporary files');
            wp_remote_post(rest_url('backsheep/v1/backup/clean'), [
                'method'    => 'POST',
                'blocking'  => false,
                'headers'   => ['Content-Type' => 'application/json'],
                'body'      => json_encode($payload),
                'timeout'   => 0.1
            ]);
        }

        return new WP_REST_Response(['status'=>'SUCCESS','state'=>'VERIFY_OK','message'=>"$file verified"], 200);
    } catch (Exception $e) {
        $msg = $e->getMessage();
        backsheep_update_status($process_id, 'ERROR', 'VERIFY_UPLOAD', $msg);
        send_fail_process_webhook($process_id, 'VERIFY_UPLOAD', $msg);
        return new WP_REST_Response(['status'=>'ERROR','state'=>'VERIFY_UPLOAD','message'=>$msg], 500);
    }
}

/**
 * CLEAN endpoint: deletes the prepared file from tmp and chains to next clean or finishes process.
 */
function backsheep_clean_endpoint(WP_REST_Request $request) {
    $params = $request->get_json_params();
    if (empty($params)) $params = $request->get_params();

    $process_id = sanitize_text_field($params['process_id'] ?? '');
    $backup_dir = $params['backup_dir'] ?? '';
    $dropbox_token = $params['dropbox_token'] ?? '';
    $file = $params['file'] ?? '';
    $remaining = backsheep_normalize_array_param($params['remaining'] ?? []);
    $all_files = backsheep_normalize_array_param($params['all_files'] ?? []);

    if (!$process_id || !$backup_dir || !$file || !htautobackup_validate_process_id($process_id)) {
        return new WP_REST_Response(['status'=>'ERROR','state'=>'CLEAN_BACKUPS','message'=>'process_id, backup_dir and file are required'], 400);
    }

    $process_dir = rtrim($backup_dir, DIRECTORY_SEPARATOR);
    $file_path = $process_dir . DIRECTORY_SEPARATOR . $file;

    try {
        backsheep_update_status($process_id, 'SUCCESS', 'CLEAN_BACKUPS', "Cleaning $file from temporary storage");

        if (file_exists($file_path)) {
            @unlink($file_path);
        }

        backsheep_update_status($process_id, 'SUCCESS', 'CLEAN_BACKUPS', "$file removed from temporary storage");

        if (!empty($remaining)) {
            $next_file = array_shift($remaining);
            $payload = [
                'process_id'    => $process_id,
                'dropbox_token' => $dropbox_token,
                'backup_dir'    => $backup_dir,
                'file'          => $next_file,
                'remaining'     => $remaining,
                'all_files'     => $all_files
            ];
            wp_remote_post(rest_url('backsheep/v1/backup/clean'), [
                'method'    => 'POST',
                'blocking'  => false,
                'headers'   => ['Content-Type' => 'application/json'],
                'body'      => json_encode($payload),
                'timeout'   => 0.1
            ]);
        } else {
            backsheep_update_status($process_id, 'SUCCESS', 'BACKUP_COMPLETED', "Backup process completed successfully");
            send_process_webhook($process_id);
        }

        return new WP_REST_Response(['status'=>'SUCCESS','state'=>'CLEAN_BACKUPS','message'=>"$file cleaned"], 200);
    } catch (Exception $e) {
        $msg = $e->getMessage();
        backsheep_update_status($process_id, 'ERROR', 'CLEAN_BACKUPS', $msg);
        send_fail_process_webhook($process_id, 'CLEAN_BACKUPS', $msg);
        return new WP_REST_Response(['status'=>'ERROR','state'=>'CLEAN_BACKUPS','message'=>$msg], 500);
    }
}

function verify_uploads($file_path, $dropbox_token, $timestamp) 
{
    $filename = basename($file_path);
    
    $site_domain = parse_url(get_site_url(), PHP_URL_HOST);
    $dropbox_path = "/MCCLOUD - BACKUPS/{$site_domain}/{$timestamp}/". basename($file_path);
    
    try {
        $ch = curl_init('https://api.dropboxapi.com/2/files/get_metadata');
        
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $dropbox_token,
            'Content-Type: application/json'
        ]);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
            "path" => $dropbox_path,
            "include_media_info" => false,
            "include_deleted" => false,
            "include_has_explicit_shared_members" => false
        ]));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        
        curl_close($ch);
        
        if ($error) {
            return [
                'success' => false,
                'message' => "CURL Error while verifying file: $error",
            ];
        }
        
        $response_data = json_decode($response, true);
        
        if ($http_code == 200) {
            return [
                'success' => true,
                'message' => "File '$filename' verified successfully",
            ];
        } else {
            return [
                'success' => false,
                'message' => "File '$filename' not found on Dropbox",
            ];
        }
    } catch (Exception $e) {
        return [
            'success' => false,
            'message' => "Exception while verifying file: " . $e->getMessage(),
        ];
    }
}

function verify_token($access_token, $timestamp)
{
    if (empty($access_token)) {
        return [
            'status' => "ERROR",
            'state' => 'VERIFY_ACCESS_TOKEN',
            'message' => "Access token is required"
        ];
    }

    try {
        $file_contents = "Token verification at " . date('Y-m-d H:i:s');
        $site_domain = parse_url(get_site_url(), PHP_URL_HOST);
        $dropbox_path = "/MCCLOUD - BACKUPS/{$site_domain}/{$timestamp}/verification.txt";
        
        $ch = curl_init('https://content.dropboxapi.com/2/files/upload');
        
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $access_token,
            'Content-Type: application/octet-stream',
            'Dropbox-API-Arg: ' . json_encode([
                "path" => $dropbox_path,
                "mode" => "add",
                "autorename" => true,
                "mute" => false
            ])
        ]);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $file_contents);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        
        curl_close($ch);

        $delete_ch = curl_init('https://api.dropboxapi.com/2/files/delete_v2');
        curl_setopt($delete_ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $access_token,
            'Content-Type: application/json'
        ]);
        curl_setopt($delete_ch, CURLOPT_POST, true);
        curl_setopt($delete_ch, CURLOPT_POSTFIELDS, json_encode([ "path" => $dropbox_path ]));
        curl_setopt($delete_ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($delete_ch, CURLOPT_TIMEOUT, 30);
        curl_close($delete_ch);
        
        if ($error) {
            return [
                'status' => "ERROR",
                'state' => 'VERIFY_ACCESS_TOKEN',
                'message' => "CURL Error: $error"
            ];
        }
        
        $response_data = json_decode($response, true);
        
        if ($http_code >= 200 && $http_code < 300) {
            return [
                'status' => "SUCCESS",
                'state' => 'VERIFY_ACCESS_TOKEN',
                'message' => "Token verified successfully",
            ];
        } else {
            return [
                'status' => "ERROR",
                'state' => 'VERIFY_ACCESS_TOKEN',
                'message' => "API Error: " . ($response_data['error_summary'] ?? $response),
            ];
        }
    } catch (Exception $e) {
        return [
            'status' => "ERROR",
            'state' => 'VERIFY_ACCESS_TOKEN',
            'message' => "Exception: " . $e->getMessage()
        ];
    }
}

function normalize_and_escape_path($path)
{
    $path = str_replace('/', DIRECTORY_SEPARATOR, $path);
    $path = str_replace('\\', '\\\\', $path);
    return $path;
}

function create_zip($sourceFolder, $targetFolder, $zipName, $excludeFolders = [])
{
    try {
        $sourceFolder = realpath($sourceFolder);
        if (!$sourceFolder || !is_dir($sourceFolder)) {
            return ['success' => false, 'message' => "Source folder not found: $zipName", 'path' => null];
        }

        $targetFolder = realpath($targetFolder);
        if (!$targetFolder || !is_dir($targetFolder)) {
            return ['success' => false, 'message' => "Target folder not found: $zipName", 'path' => null];
        }

        $zipPath = $targetFolder . DIRECTORY_SEPARATOR . $zipName . '.zip';
        $fp = fopen($zipPath, 'w');
        if (!$fp) {
            return ['success' => false, 'message' => "Failed to create output file: $zipPath", 'path' => null];
        }

        // Setup ZipStream
        $options = new Archive();
        $options->setOutputStream($fp);
        $options->setSendHttpHeaders(false);

        $zip = new ZipStream(null, $options);

        $baseFolder = basename($sourceFolder);

        $it = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($sourceFolder, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::LEAVES_ONLY
        );

        foreach ($it as $file) {
            if ($file->isDir()) {
                continue;
            }

            $filePath = $file->getPathname();
            $relative = substr($filePath, strlen($sourceFolder) + 1);
            $entryName = $baseFolder . '/' . str_replace('\\', '/', $relative);

            // Exclude check
            $skip = false;
            foreach ($excludeFolders as $exclude) {
                if (strpos($entryName, $exclude . '/') !== false) {
                    $skip = true;
                    break;
                }
            }

            if ($skip) {
                continue;
            }

            $fileOpt = new FileOptions();
            $fileOpt->setMethod(Method::DEFLATE()); 

            $zip->addFileFromPath($entryName, $filePath, $fileOpt);
        }

        $zip->finish();
        fclose($fp);

        return ['success' => true, 'message' => "Backup created successfully: $zipName", 'path' => $zipPath];
    } catch (Exception $e) {
        if (isset($fp) && is_resource($fp)) {
            fclose($fp);
        }
        if (isset($zipPath) && file_exists($zipPath)) {
            unlink($zipPath);
        }
        return ['success' => false, 'message' => "Zip creation error: " . $e->getMessage(), 'path' => null];
    }
}

function upload_to_dropbox($file_path, $access_token, $timestamp) {
    if (!file_exists($file_path)) {
        return [
            'success' => false,
            'message' => "Backup file not found: $file_path"
        ];
    }

    $file_size = filesize($file_path);
    $site_domain = parse_url(get_site_url(), PHP_URL_HOST);
    $dropbox_path = "/MCCLOUD - BACKUPS/{$site_domain}/{$timestamp}/". basename($file_path);
    
    
    $chunk_size = 4 * 1024 * 1024; 
    
    $fp = fopen($file_path, 'rb');
    $session_id = null;
    
    try {
        // Step 1: Start upload session with first chunk
        $first_chunk = fread($fp, $chunk_size);
        $actual_chunk_size = strlen($first_chunk);
        $session_result = start_upload_session($first_chunk, $access_token);
        
        if (!isset($session_result['session_id'])) {
            fclose($fp);
            return [
                'success' => false,
                'message' => "Failed to start upload session: " . json_encode($session_result),
            ];
        }
        
        $session_id = $session_result['session_id'];
        $offset = $actual_chunk_size;
        
        // Step 2: Append chunks until near the end of file
        while ($offset < $file_size - $chunk_size) {
            $chunk_data = fread($fp, $chunk_size);
            $actual_chunk_size = strlen($chunk_data);
            
            if ($actual_chunk_size == 0) {
                break;
            }
            
            $append_result = append_to_session($session_id, $offset, $chunk_data, $access_token);
            if (!$append_result['success']) {
                fclose($fp);
                return [
                    'success' => false,
                    'message' => "Failed to append to upload session: " . $append_result['message'],
                ];
            }
            $offset += $actual_chunk_size;
        }
        
        // Step 3: Finish upload with the last chunk
        $last_chunk = '';
        while (!feof($fp)) {
            $last_chunk .= fread($fp, 8192);
        }
        
        $finish_result = finish_upload_session($session_id, $offset, $last_chunk, $dropbox_path, $access_token);
        fclose($fp);
        
        if (isset($finish_result['error']) || isset($finish_result['.tag'])) {
            return [
                'success' => false,
                'message' => "Failed to finish upload session: " . json_encode($finish_result),
            ];
        }
        
        return [
            'success' => true,
            'message' => "Backup file uploaded successfully",
        ];
        
    } catch (Exception $e) {
        if ($fp) {
            fclose($fp);
        }
        return [
            'success' => false,
            'message' => "Exception during upload: " . $e->getMessage(),
        ];
    }
}

function start_upload_session($chunk_data, $access_token) {
    $ch = curl_init('https://content.dropboxapi.com/2/files/upload_session/start');
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $access_token,
        'Content-Type: application/octet-stream',
        'Dropbox-API-Arg: ' . json_encode([
            'close' => false
        ])
    ]);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $chunk_data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($http_code == 200) {
        return json_decode($response, true);
    }
    
    return ['error' => $error ?: $response];
}

function append_to_session($session_id, $offset, $chunk_data, $access_token) {
    $ch = curl_init('https://content.dropboxapi.com/2/files/upload_session/append_v2');
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $access_token,
        'Content-Type: application/octet-stream',
        'Dropbox-API-Arg: ' . json_encode([
            'cursor' => [
                'session_id' => $session_id,
                'offset' => $offset
            ],
            'close' => false
        ])
    ]);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $chunk_data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($http_code == 200) {
        return ['success' => true];
    }
    
    $response_data = json_decode($response, true);
    if (isset($response_data['.tag']) && $response_data['.tag'] == 'incorrect_offset') {
        return [
            'success' => false, 
            'message' => 'Incorrect offset. Expected: ' . 
                (isset($response_data['correct_offset']) ? $response_data['correct_offset'] : 'unknown')
        ];
    }
    
    return ['success' => false, 'message' => $error ?: $response];
}

function finish_upload_session($session_id, $offset, $last_chunk, $dropbox_path, $access_token) {
    $ch = curl_init('https://content.dropboxapi.com/2/files/upload_session/finish');
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $access_token,
        'Content-Type: application/octet-stream',
        'Dropbox-API-Arg: ' . json_encode([
            'cursor' => [
                'session_id' => $session_id,
                'offset' => $offset
            ],
            'commit' => [
                'path' => $dropbox_path,
                'mode' => 'add',
                'autorename' => true,
                'mute' => false
            ]
        ])
    ]);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $last_chunk);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);

    curl_close($ch);
    
    $response_data = json_decode($response, true);
    if ($http_code != 200 || isset($response_data['.tag'])) {
        if (isset($response_data['error']) && isset($response_data['error']['.tag']) && 
            $response_data['error']['.tag'] == 'lookup_failed' && 
            isset($response_data['error']['lookup_failed']) && 
            isset($response_data['error']['lookup_failed']['.tag']) && 
            $response_data['error']['lookup_failed']['.tag'] == 'incorrect_offset' && 
            isset($response_data['error']['lookup_failed']['correct_offset'])) {
            
            return [
                '.tag' => 'lookup_failed',
                'lookup_failed' => [
                    '.tag' => 'incorrect_offset',
                    'correct_offset' => $response_data['error']['lookup_failed']['correct_offset']
                ]
            ];
        }
        return $response_data ?: ['error' => $error ?: 'Unknown error'];
    }
    
    return $response_data;
}

function get_process_created_timestamp($process_id) {
    $crud = new CRUD();
    $process = $crud->get_row("SELECT * FROM `{$crud->log_table()}` WHERE process_id='$process_id' ORDER BY id ASC LIMIT 1");
    return isset($process['time_stamp']) ? $process['time_stamp'] : null;
}

function send_process_webhook($process_id) {

    $webhook = get_option('ht_autobackup_webhook');
    if(!$webhook){
        return;
    }
    $webhook = rtrim($webhook);
    $webhook_url = $webhook.'/api/backup/webhook/status-update';

    $body = json_encode([
        'processId' => $process_id,
    ]);

    $args = [
        'headers' => [
            'Content-Type' => 'application/json',
        ],
        'body' => $body,
        'timeout' => 1,
        'blocking' => false,
    ];

    $response = wp_remote_post($webhook_url, $args);

}

function send_fail_process_webhook($process_id, $status, $message="") {

    $webhook = get_option('ht_autobackup_webhook');
    if(!$webhook){
        return;
    }
    $webhook = rtrim($webhook);
    $webhook_url = $webhook.'/api/backup/webhook/status-update/fail';

    $body = json_encode([
        'processId' => $process_id,
        "status" => $status,
        "message" => $message,
    ]);

    $args = [
        'headers' => [
            'Content-Type' => 'application/json',
        ],
        'body' => $body,
        'timeout' => 1,
        'blocking' => false,
    ];

    $response = wp_remote_post($webhook_url, $args);
}

function snooze() { sleep(1); }

function htautobackup_validate_process_id($process_id) {
    if (!is_string($process_id) || strlen($process_id) < 3) {
        return false;
    }
    return (strpos($process_id, 'ht_') === 0);
}
