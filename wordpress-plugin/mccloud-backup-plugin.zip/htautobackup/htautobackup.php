<?php
/*
    Plugin Name: Heaventree Auto Backup
    Description: Backup WordPress site (themes, plugins, uploads, DB, wp-config) and upload to Dropbox.
    Version: 1.0.1
    Author: Heaventree
*/

if (!defined('ABSPATH'))
    exit;

@set_time_limit(0);
@ini_set('memory_limit', '512M');
@ignore_user_abort(true);

add_action('rest_api_init', function () {
    register_rest_route('backsheep/v1', '/backup/start', [
        'methods' => 'POST',
        'callback' => 'backsheep_start_backup',
        'permission_callback' => '__return_true'
    ]);

    register_rest_route('backsheep/v1', '/backup/run', [
        'methods' => 'POST',
        'callback' => 'backsheep_run_backup',
        'permission_callback' => '__return_true'
    ]);

    register_rest_route('backsheep/v1', '/backup/status', [
        'methods' => 'POST',
        'callback' => 'backsheep_check_backup_status',
        'permission_callback' => '__return_true'
    ]);

    register_rest_route('backsheep/v1', '/backup/status/log', [
        'methods' => 'POST',
        'callback' => 'backsheep_check_backup_log',
        'permission_callback' => '__return_true'
    ]);
});

add_action('backsheep_do_backup', 'backsheep_prepare_backup', 10, 4);
add_action('admin_init', 'ht_autobackup_settings_init');
add_action('admin_menu', 'ht_autobackup_add_admin_menu');
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'ht_autobackup_add_settings_link');

function ht_autobackup_settings_init() {
    register_setting('ht_autobackup_settings_group', 'ht_autobackup_webhook');
    register_setting('ht_autobackup_settings_group', 'ht_autobackup_token');

    add_settings_section(
        'ht_autobackup_section',
        'HT Autobackup Settings',
        null,
        'htautobackup'
    );

    add_settings_field(
        'ht_autobackup_webhook_field',
        'Webhook URL',
        'ht_autobackup_webhook_field_render',
        'htautobackup',
        'ht_autobackup_section'
    );

    add_settings_field(
        'ht_autobackup_token_field',
        'Backup Token',
        'ht_autobackup_token_field_render',
        'htautobackup',
        'ht_autobackup_section'
    );
}

function ht_autobackup_webhook_field_render() {
    $value = get_option('ht_autobackup_webhook');
    echo '<input type="url" name="ht_autobackup_webhook" value="' . esc_attr($value) . '" size="50" />';
}

function ht_autobackup_token_field_render() {
    $value = get_option('ht_autobackup_token');
    echo '<input type="password" name="ht_autobackup_token" value="' . esc_attr($value) . '" />';
}

function ht_autobackup_add_admin_menu() {
    add_submenu_page(
        null,
        'HT Autobackup Settings',
        'HT Autobackup Settings',
        'manage_options',
        'htautobackup',
        'ht_autobackup_settings_page'
    );
}

function ht_autobackup_settings_page() {
    ?>
    <div class="wrap">
        <form method="post" action="options.php">
            <?php
                settings_fields('ht_autobackup_settings_group');
                do_settings_sections('htautobackup');
                submit_button('Save Settings');
            ?>
        </form>
    </div>
    <?php
}

function ht_autobackup_add_settings_link($links) {
    $settings_link = '<a href="' . admin_url('admin.php?page=htautobackup') . '">Settings</a>';
    array_unshift($links, $settings_link);
    return $links;
}

function backsheep_start_backup(WP_REST_Request $request)
{
    
    $process_id = uniqid('bs_', true);
    $base_dir = plugin_dir_path(__FILE__);
    $tmp_dir = $base_dir . 'tmp/';
    $process_dir = $tmp_dir . $process_id;

    if (!file_exists($tmp_dir)) {
        mkdir($tmp_dir, 0777, true);
    }

    $status_file = "$process_dir/status.json";
    $status_log = "$process_dir/log.json";

    mkdir($process_dir, 0777, true);
    $site_domain = parse_url(get_site_url(), PHP_URL_HOST);

    $timestamp = date('Y-m-d_H-i-s');
    $dropbox_path = "/MCCLOUD - BACKUPS/{$site_domain}/{$timestamp}/";

    file_put_contents($status_file, json_encode([
        'status' => 'SUCCESS',
        'state' =>"PROCESS_CREATED",
        'progress' => 'Process created successfully!',
        'path' => $dropbox_path,
    ]));

    $log_arr[$timestamp] = [ 'status' => 'SUCCESS', 'state' =>"PROCESS_CREATED", 'progress' => 'Process created successfully!'];

    file_put_contents($status_log, json_encode($log_arr ));

    return new WP_REST_Response(['status' => "SUCCESS", 'state' =>"PROCESS_CREATED", "message" => "Backup process created successfully!", 'process_id' => $process_id ,'path' => $dropbox_path, 'token'=> get_option('ht_autobackup_token')]);
}

function backsheep_run_backup(WP_REST_Request $request){

    $process_id = $request->get_param('process_id');
    $dropbox_token = $request->get_param('dropbox_token');
    $mode = $request->get_param('mode') ?? "ALL";
    if (!$process_id) {
        return new WP_REST_Response(['status'=> "ERROR", 'state'=>"MISSING_PROCESS_ID", 'message' => 'Missing process_id'], 400);
    }
    if (!$dropbox_token) {
        return new WP_REST_Response(['status'=> "ERROR", 'state'=>"MISSING_TOKEN", 'message' => 'Missing Dropbox token'], 400);
    }
    
    $base_dir = plugin_dir_path(__FILE__);
    $tmp_dir = $base_dir . 'tmp/';
    $process_dir = $tmp_dir . $process_id;
    $backup_dir = "$process_dir";
    $status_file = "$process_dir/status.json";

    $response = new WP_REST_Response([
        'status' => 'SUCCESS',
        'state'=>"PROCESS_RUNNING",
        'message' => 'Backup process rinning'
    ]);
    $response->set_status(200);
    
    @ob_end_clean();
    header('Connection: close');
    ob_start();
    echo json_encode($response->get_data());
    $size = ob_get_length();
    header("Content-Length: $size");
    ob_end_flush();
    flush();
    
    $status_data = json_decode(file_get_contents($status_file), true);
    
    if (isset($status_data['state']) && in_array($status_data['state'], ["PROCESS_CREATED", "MISSING_PROCESS_ID", "MISSING_TOKEN"])) {
        backsheep_prepare_backup($dropbox_token, $process_id, $process_dir, $mode);
    }

}

function backsheep_check_backup_status(WP_REST_Request $request)
{
    $process_id = $request->get_param('process_id');
    if (!$process_id) {
        return new WP_REST_Response(['status'=> "ERROR", 'state'=>"MISSING_PROCESS_ID", 'message' => 'Missing process_id'], 400);
    }

    $backup_dir = plugin_dir_path(__FILE__) . "tmp/$process_id/status.json";
    if (!file_exists($backup_dir)) {
        return new WP_REST_Response(['status'=> "ERROR", 'state'=>"INVALID_PROCESS_ID", 'message' => 'Invalid process_id'], 404);
    }

    $status = json_decode(file_get_contents($backup_dir), true);
    return new WP_REST_Response($status);
}

function backsheep_check_backup_log(WP_REST_Request $request)
{
    $process_id = $request->get_param('process_id');
    if (!$process_id) {
        return new WP_REST_Response([
            'status' => "ERROR",
            'state' => "MISSING_PROCESS_ID",
            'message' => 'Missing process_id'
        ], 400);
    }

    $log_file = plugin_dir_path(__FILE__) . "tmp/$process_id/log.json";

    if (!file_exists($log_file)) {
        return new WP_REST_Response([
            'status' => "ERROR",
            'state' => "INVALID_PROCESS_ID",
            'message' => 'Invalid process_id'
        ], 404);
    }

    $log = json_decode(file_get_contents($log_file), true);

    if (!is_array($log)) {
        return new WP_REST_Response([
            'status' => "ERROR",
            'state' => "LOG_PARSE_ERROR",
            'message' => 'Failed to parse log file'
        ], 500);
    }

    return new WP_REST_Response([
        'status' => "SUCCESS",
        'state' => "LOG_LOADED",
        'message' => 'Log loaded successfully',
        'log' => $log
    ]);
}

function backsheep_update_status($backup_dir, $status, $state, $message)
{
    $status_file = "$backup_dir/status.json";
    $status_log = "$backup_dir/log.json";

    $status_array = [
        'status' => $status,
        'state' => $state,
        'message' => $message,
    ];

    file_put_contents($status_file, json_encode($status_array, JSON_PRETTY_PRINT));

    $timestamp = date('Y-m-d_H-i-s');
    $log_entry = [
        $timestamp => $status_array,
    ];

    $existing_log = [];
    if (file_exists($status_log)) {
        $existing_log = json_decode(file_get_contents($status_log), true);
        if (!is_array($existing_log)) {
            $existing_log = [];
        }
    }

    $updated_log = array_merge($existing_log, $log_entry);

    file_put_contents($status_log, json_encode($updated_log, JSON_PRETTY_PRINT));
    snooze();
}

function backsheep_prepare_backup($dropbox_token, $process_id, $backup_dir , $mode = "ALL")
{
    try {
        $process_db = false;
        $process_file = false;
        $backup = [];
        
        if($mode == "DB"){
            $process_db = true;
            $backup[] = "database.sql";
            
        }elseif($mode == "FILE"){
            $process_file = true;
            $backup[] = "wp-config.php";
            $backup[] = "themes.zip";
            // $backup[] = "uploads.zip";
            // $backup[] = "plugins.zip";
            
        }else{
            $process_db = true;
            $process_file = true;
            $backup[] = "database.sql";
            $backup[] = "wp-config.php";
            $backup[] = "themes.zip";
            // $backup[] = "uploads.zip";
            // $backup[] = "plugins.zip";
        }

        $timestamp = get_process_created_timestamp($process_id);
        backsheep_update_status($backup_dir, 'SUCCESS', "VERIFY_ACCESS_TOKEN" , "Verifying Dropbox access token");
        $verify_token = verify_token($dropbox_token, $timestamp);
        
        if($verify_token['status'] == "ERROR"){
            throw new Exception(json_encode($verify_token));
        }else{
            backsheep_update_status($backup_dir, $verify_token['status'], $verify_token['state'], $verify_token['message']);
        }

        if($process_db){

            global $wpdb;
            
            // Step 1: DB Backup
            $base_dir = plugin_dir_path(__FILE__);
            $tmp_dir = $base_dir . 'tmp/';
            $process_dir = $tmp_dir . $process_id;
            
            // Step 2: DB Backup
            $db_file = "$process_dir/database.sql";
            backsheep_update_status($backup_dir, 'SUCCESS', "BACKUP_DATABASE" , "Database backup started");
            
            $tables = $wpdb->get_col("SHOW TABLES");
            backsheep_update_status($backup_dir, 'SUCCESS', "BACKUP_DATABASE" , "Found " . count($tables) . " tables to backup");
            
            $sql_dump = "";
            foreach ($tables as $table) {
                backsheep_update_status($backup_dir, 'SUCCESS', "BACKUP_DATABASE", "Backing up table: $table");
                $create_table = $wpdb->get_row("SHOW CREATE TABLE `$table`", ARRAY_N);
                $sql_dump .= "\n\n-- Table structure for `$table`\n";
                $sql_dump .= $create_table[1] . ";\n\n";
                
                $rows = $wpdb->get_results("SELECT * FROM `$table`", ARRAY_A);
                if (!empty($rows)) {
                    $sql_dump .= "-- Dumping data for table `$table`\n";
                    foreach ($rows as $row) {
                        $columns = array_map(fn($val) => '`' . esc_sql($val) . '`', array_keys($row));
                        $values = array_map(function ($val) {
                            if ($val === null)
                                return 'NULL';
                            return "'" . esc_sql($val) . "'";
                        }, array_values($row));
                        $sql_dump .= "INSERT INTO `$table` (" . implode(", ", $columns) . ") VALUES (" . implode(", ", $values) . ");\n";
                    }
                    $sql_dump .= "\n";
                }
            }
            
            $wp_config_path = ABSPATH . 'wp-config.php';
            $wp_config_backup = $process_dir . '/wp-config.php';
            if (file_exists($wp_config_path)) {
                backsheep_update_status($backup_dir, 'SUCCESS', "BACKUP_DATABASE" , "Backing up wp-config.php");
                if (!copy($wp_config_path, $wp_config_backup)) {
                    throw new Exception(json_encode(array("status"=>"ERROR", "state"=>"BACKUP_DATABASE", "message"=>"Failed to backup wp-config.php")));
                }
                backsheep_update_status($backup_dir, 'SUCCESS', "BACKUP_DATABASE" , "wp-config.php backed up");
            } else {
                backsheep_update_status($backup_dir, 'SUCCESS', "BACKUP_DATABASE" , "wp-config.php not found");
            }

            file_put_contents($db_file, $sql_dump);
            backsheep_update_status($backup_dir, 'SUCCESS', "BACKUP_DATABASE" , "Database backup completed");

        }

        if($process_file){
            // Folders Backup
            $upload_dir = normalize_and_escape_path(wp_upload_dir()['basedir']);
            $theme_dir = normalize_and_escape_path(get_theme_root());
            $plugin_dir = normalize_and_escape_path(WP_PLUGIN_DIR);

            $folders = [
                'themes' => $theme_dir,
                // 'uploads' => $upload_dir,
                // 'plugins' => $plugin_dir,
            ];
            backsheep_update_status($backup_dir, 'SUCCESS', "BACKUP_FILES" , "Files backup started");

            foreach ($folders as $name => $path) {
                backsheep_update_status($backup_dir, 'SUCCESS', "BACKUP_FILES" , "Preparing backup of $name folder");
                $zr = create_zip($path, $process_dir, $name);
                if ($zr['success']) {
                    backsheep_update_status($backup_dir,'SUCCESS', "BACKUP_FILES" , $zr['message']);
                } else {
                    throw new Exception(json_encode(array("status"=>"ERROR", "state"=>"BACKUP_FILES", "message"=>$zr['message'])));
                }
            }
            backsheep_update_status($backup_dir, 'SUCCESS', "BACKUP_FILES" , "Files backup created");
        }

        // now uploading to Dropbox
        backsheep_update_status($backup_dir, 'SUCCESS', "BACKUP_UPLOAD" , "Uploading backup files");
        foreach ($backup as $file) {
            backsheep_update_status($backup_dir, 'SUCCESS', "BACKUP_UPLOAD" , "Uploading $file");

            $file_path = normalize_and_escape_path($process_dir . '/' . $file);
            $response = upload_to_dropbox($file_path, $dropbox_token, $timestamp);
            
            if (!$response['success']) {
                backsheep_update_status($backup_dir, 'ERROR', "BACKUP_UPLOAD" , "Failed to upload backup file: $file");
                throw new Exception(json_encode(array("status"=>"ERROR", "state"=>"BACKUP_UPLOAD", "message"=>"Failed to upload backup file: $file")));
            }
            backsheep_update_status($backup_dir, 'SUCCESS', "BACKUP_UPLOAD" , "Backup file uploaded successfully: $file");
        }

        backsheep_update_status($backup_dir, 'SUCCESS', "VERIFY_UPLOAD" , "Verifying backup files");
        foreach ($backup as $file) {
            backsheep_update_status($backup_dir, 'SUCCESS', "VERIFY_UPLOAD" , "Verifying $file");

            $file_path = normalize_and_escape_path($process_dir . '/' . $file);
            $response = verify_uploads($file_path, $dropbox_token, $timestamp);
            
            if (!$response['success']) {
                backsheep_update_status($backup_dir, 'ERROR', "VERIFY_UPLOAD" , $response['message']);
                throw new Exception(json_encode(array("status"=>"ERROR", "state"=>"VERIFY_UPLOAD", "message"=>$response['message'])));
            }
            backsheep_update_status($backup_dir, 'SUCCESS', "VERIFY_UPLOAD" , "Backup file verified successfully: $file");
        }
        
        backsheep_update_status($backup_dir, 'SUCCESS', "BACKUP_UPLOAD" , "All backup files uploaded and verified");
        
        // Step 6: Cleaning
        backsheep_update_status($backup_dir, 'SUCCESS', "CLEAN_BACKUPS" , "Temporary file cleaning started");
        
        clean_temp($process_dir, ["status.json", "log.json"]);

        send_process_webhook($process_id);
        
        backsheep_update_status($backup_dir, 'SUCCESS', "CLEAN_BACKUPS" , "Temporary files cleaned successfully");
        backsheep_update_status($backup_dir, 'SUCCESS', "BACKUP_COMPLETED" , "Backup process completed successfully");
    } catch (Exception $e) {
        $error = json_decode($e->getMessage(), true);
        backsheep_update_status($backup_dir, $error['status'], $error['state'], $error['message']);
    }
}


function verify_uploads($file_path, $dropbox_token, $timestamp) 
{
    $filename = basename($file_path);
    
    $site_domain = parse_url(get_site_url(), PHP_URL_HOST);
    $dropbox_path = "/MCCLOUD - BACKUPS/{$site_domain}/{$timestamp}/". basename($file_path);
    
    try {
        $ch = curl_init('https://api.dropboxapi.com/2/files/get_metadata');
        
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $dropbox_token,
            'Content-Type: application/json'
        ]);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
            "path" => $dropbox_path,
            "include_media_info" => false,
            "include_deleted" => false,
            "include_has_explicit_shared_members" => false
        ]));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        
        curl_close($ch);
        
        if ($error) {
            return [
                'success' => false,
                'message' => "CURL Error while verifying file: $error",
            ];
        }
        
        $response_data = json_decode($response, true);
        
        if ($http_code == 200) {
            return [
                'success' => true,
                'message' => "File '$filename' verified successfully",
            ];
        } else {
            return [
                'success' => false,
                'message' => "File '$filename' not found on Dropbox",
            ];
        }
    } catch (Exception $e) {
        return [
            'success' => false,
            'message' => "Exception while verifying file: " . $e->getMessage(),
        ];
    }
}

function verify_token($access_token, $timestamp)
{
    if (empty($access_token)) {
        return [
            'status' => "ERROR",
            'state' => 'VERIFY_ACCESS_TOKEN',
            'message' => "Access token is required"
        ];
    }

    try {
        $file_contents = "Token verification at " . date('Y-m-d H:i:s');
        $site_domain = parse_url(get_site_url(), PHP_URL_HOST);
        $dropbox_path = "/MCCLOUD - BACKUPS/{$site_domain}/{$timestamp}/verification.txt";
        
        $ch = curl_init('https://content.dropboxapi.com/2/files/upload');
        
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $access_token,
            'Content-Type: application/octet-stream',
            'Dropbox-API-Arg: ' . json_encode([
                "path" => $dropbox_path,
                "mode" => "add",
                "autorename" => true,
                "mute" => false
            ])
        ]);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $file_contents);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        
        curl_close($ch);

        $delete_ch = curl_init('https://api.dropboxapi.com/2/files/delete_v2');
        curl_setopt($delete_ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $access_token,
            'Content-Type: application/json'
        ]);
        curl_setopt($delete_ch, CURLOPT_POST, true);
        curl_setopt($delete_ch, CURLOPT_POSTFIELDS, json_encode([ "path" => $dropbox_path ]));
        curl_setopt($delete_ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($delete_ch, CURLOPT_TIMEOUT, 30);
        curl_close($delete_ch);
        
        if ($error) {
            return [
                'status' => "ERROR",
                'state' => 'VERIFY_ACCESS_TOKEN',
                'message' => "CURL Error: $error"
            ];
        }
        
        $response_data = json_decode($response, true);
        
        if ($http_code >= 200 && $http_code < 300) {
            return [
                'status' => "SUCCESS",
                'state' => 'VERIFY_ACCESS_TOKEN',
                'message' => "Token verified successfully",
            ];
        } else {
            return [
                'status' => "ERROR",
                'state' => 'VERIFY_ACCESS_TOKEN',
                'message' => "API Error: " . ($response_data['error_summary'] ?? $response),
            ];
        }
    } catch (Exception $e) {
        return [
            'status' => "ERROR",
            'state' => 'VERIFY_ACCESS_TOKEN',
            'message' => "Exception: " . $e->getMessage()
        ];
    }
}

function normalize_and_escape_path($path)
{
    $path = str_replace('/', DIRECTORY_SEPARATOR, $path);
    $path = str_replace('\\', '\\\\', $path);
    return $path;
}

function create_zip($sourceFolder, $targetFolder, $zipName)
{
    try {
        $sourceFolder = realpath($sourceFolder);
        if (!$sourceFolder || !is_dir($sourceFolder)) {
            return [
                'success' => false,
                'message' => "Source folder not found: $zipName"
            ];
        }

        $targetFolder = realpath($targetFolder);
        if (!$targetFolder || !is_dir($targetFolder)) {
            return [
                'success' => false,
                'message' => "Target folder not found: $zipName"
            ];
        }

        $zipPath = $targetFolder . DIRECTORY_SEPARATOR . $zipName . '.zip';

        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== TRUE) {
            return [
                'success' => false,
                'message' => "Failed to create backup: $zipName"
            ];
        }

        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($sourceFolder, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );

        foreach ($files as $file) {
            $filePath = $file->getRealPath();
            $relativePath = ltrim(str_replace($sourceFolder, '', $filePath), DIRECTORY_SEPARATOR);

            if ($file->isDir()) {
                $zip->addEmptyDir($relativePath);
            } else {
                $zip->addFile($filePath, $relativePath);
            }
        }

        if (!$zip->close()) {
            return [
                'success' => false,
                'message' => "Failed to create backup: $zipName"
            ];
        }

        return [
            'success' => true,
            'message' => "Backup created successfully: $zipName",
        ];
    } catch (Exception $e) {
        return [
            'success' => false,
            'message' => "Zip creation error: " . $e->getMessage()
        ];
    }
}

function clean_temp($dir_path, $exclude = []){
    if (!is_dir($dir_path)) {
        return false;
    }
    
    $exclude_files = array_map('basename', $exclude);
    $files = scandir($dir_path);
    foreach ($files as $file) {
        if ($file === '.' || $file === '..') {
            continue;
        }
        
        if (in_array($file, $exclude_files)) {
            continue;
        }
        
        $full_path = $dir_path . DIRECTORY_SEPARATOR . $file;
        if (is_file($full_path)) {
            unlink($full_path);
        }
    }
    return true;
}

function upload_to_dropbox($file_path, $access_token, $timestamp) {
    if (!file_exists($file_path)) {
        return [
            'success' => false,
            'message' => "Backup file not found: $file_path"
        ];
    }

    $file_size = filesize($file_path);
    $site_domain = parse_url(get_site_url(), PHP_URL_HOST);
    $dropbox_path = "/MCCLOUD - BACKUPS/{$site_domain}/{$timestamp}/". basename($file_path);
    
    
    $chunk_size = 4 * 1024 * 1024; 
    
    $fp = fopen($file_path, 'rb');
    $session_id = null;
    
    try {
        // Step 1: Start upload session with first chunk
        $first_chunk = fread($fp, $chunk_size);
        $actual_chunk_size = strlen($first_chunk);
        $session_result = start_upload_session($first_chunk, $access_token);
        
        if (!isset($session_result['session_id'])) {
            fclose($fp);
            return [
                'success' => false,
                'message' => "Failed to start upload session: " . json_encode($session_result),
            ];
        }
        
        $session_id = $session_result['session_id'];
        $offset = $actual_chunk_size;
        
        // Step 2: Append chunks until near the end of file
        while ($offset < $file_size - $chunk_size) {
            $chunk_data = fread($fp, $chunk_size);
            $actual_chunk_size = strlen($chunk_data);
            
            if ($actual_chunk_size == 0) {
                break;
            }
            
            $append_result = append_to_session($session_id, $offset, $chunk_data, $access_token);
            if (!$append_result['success']) {
                fclose($fp);
                return [
                    'success' => false,
                    'message' => "Failed to append to upload session: " . $append_result['message'],
                ];
            }
            $offset += $actual_chunk_size;
        }
        
        // Step 3: Finish upload with the last chunk
        $last_chunk = '';
        while (!feof($fp)) {
            $last_chunk .= fread($fp, 8192);
        }
        
        $finish_result = finish_upload_session($session_id, $offset, $last_chunk, $dropbox_path, $access_token);
        fclose($fp);
        
        if (isset($finish_result['error']) || isset($finish_result['.tag'])) {
            return [
                'success' => false,
                'message' => "Failed to finish upload session: " . json_encode($finish_result),
            ];
        }
        
        return [
            'success' => true,
            'message' => "Backup file uploaded successfully",
        ];
        
    } catch (Exception $e) {
        if ($fp) {
            fclose($fp);
        }
        return [
            'success' => false,
            'message' => "Exception during upload: " . $e->getMessage(),
        ];
    }
}

function start_upload_session($chunk_data, $access_token) {
    $ch = curl_init('https://content.dropboxapi.com/2/files/upload_session/start');
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $access_token,
        'Content-Type: application/octet-stream',
        'Dropbox-API-Arg: ' . json_encode([
            'close' => false
        ])
    ]);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $chunk_data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($http_code == 200) {
        return json_decode($response, true);
    }
    
    return ['error' => $error ?: $response];
}

function append_to_session($session_id, $offset, $chunk_data, $access_token) {
    $ch = curl_init('https://content.dropboxapi.com/2/files/upload_session/append_v2');
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $access_token,
        'Content-Type: application/octet-stream',
        'Dropbox-API-Arg: ' . json_encode([
            'cursor' => [
                'session_id' => $session_id,
                'offset' => $offset
            ],
            'close' => false
        ])
    ]);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $chunk_data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($http_code == 200) {
        return ['success' => true];
    }
    
    $response_data = json_decode($response, true);
    if (isset($response_data['.tag']) && $response_data['.tag'] == 'incorrect_offset') {
        return [
            'success' => false, 
            'message' => 'Incorrect offset. Expected: ' . 
                (isset($response_data['correct_offset']) ? $response_data['correct_offset'] : 'unknown')
        ];
    }
    
    return ['success' => false, 'message' => $error ?: $response];
}

function finish_upload_session($session_id, $offset, $last_chunk, $dropbox_path, $access_token) {
    $ch = curl_init('https://content.dropboxapi.com/2/files/upload_session/finish');
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $access_token,
        'Content-Type: application/octet-stream',
        'Dropbox-API-Arg: ' . json_encode([
            'cursor' => [
                'session_id' => $session_id,
                'offset' => $offset
            ],
            'commit' => [
                'path' => $dropbox_path,
                'mode' => 'add',
                'autorename' => true,
                'mute' => false
            ]
        ])
    ]);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $last_chunk);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);

    curl_close($ch);
    
    $response_data = json_decode($response, true);
    if ($http_code != 200 || isset($response_data['.tag'])) {
        if (isset($response_data['error']) && isset($response_data['error']['.tag']) && 
            $response_data['error']['.tag'] == 'lookup_failed' && 
            isset($response_data['error']['lookup_failed']) && 
            isset($response_data['error']['lookup_failed']['.tag']) && 
            $response_data['error']['lookup_failed']['.tag'] == 'incorrect_offset' && 
            isset($response_data['error']['lookup_failed']['correct_offset'])) {
            
            return [
                '.tag' => 'lookup_failed',
                'lookup_failed' => [
                    '.tag' => 'incorrect_offset',
                    'correct_offset' => $response_data['error']['lookup_failed']['correct_offset']
                ]
            ];
        }
        return $response_data ?: ['error' => $error ?: 'Unknown error'];
    }
    
    return $response_data;
}

function get_process_created_timestamp($process_id) {
    $base_dir = plugin_dir_path(__FILE__);
    $status_log = $base_dir . "tmp/{$process_id}/log.json";

    if (!file_exists($status_log)) {
        return null;
    }

    $log_contents = file_get_contents($status_log);
    $log_data = json_decode($log_contents, true);

    foreach ($log_data as $timestamp => $entry) {
        if (isset($entry['state']) && $entry['state'] === 'PROCESS_CREATED') {
            return $timestamp;
        }
    }

    return null;
}

function send_process_webhook($process_id) {
    $webhook = get_option('ht_autobackup_webhook');
    if(!$webhook){
        return;
    }
    $webhook = rtrim($webhook);
    $webhook_url = $webhook.'/api/backup/webhook/status-update';

    $body = json_encode([
        'processId' => $process_id,
    ]);

    $args = [
        'headers' => [
            'Content-Type' => 'application/json',
        ],
        'body' => $body,
        'timeout' => 30,
    ];

    $response = wp_remote_post($webhook_url, $args);

}

function snooze() { sleep(1); }
