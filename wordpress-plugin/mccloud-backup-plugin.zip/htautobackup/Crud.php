<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Prevent direct access
}

class Crud {
    private $db;
    private $log_table;

    public function __construct() {
        global $wpdb;
        $this->db = $wpdb;
        $this->log_table = $wpdb->prefix . 'htautobackup_log';
    }
    public function log_table(){
        return $this->log_table;
    }

    /**
     * Execute insert/update/delete query
     */
    public function execute( $query ) {
        $result = $this->db->query( $query );
        if ( $result === false ) {
            return new WP_Error( 'db_error', $this->db->last_error );
        }
        return $result;
    }

    /**
     * Get multiple rows from DB
     */
    public function get_data( $query ) {
        return $this->db->get_results( $query, ARRAY_A );
    }

    /**
     * Get single row
     */
    public function get_row( $query ) {
        return $this->db->get_row( $query, ARRAY_A );
    }

    /**
     * Get single value
     */
    public function get_var( $query ) {
        return $this->db->get_var( $query );
    }

    /**
     * Safe insert using wpdb
     */
    public function insert( $table, $data, $format = null ) {
        $this->db->insert( $table, $data, $format );
        return $this->db->insert_id;
    }

    /**
     * Safe update using wpdb
     */
    public function update( $table, $data, $where, $format = null, $where_format = null ) {
        return $this->db->update( $table, $data, $where, $format, $where_format );
    }

    /**
     * Safe delete using wpdb
     */
    public function delete( $table, $where, $where_format = null ) {
        return $this->db->delete( $table, $where, $where_format );
    }
}
