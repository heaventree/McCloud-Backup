// npm package: dropify
// github link: https://github.com/JeremyFagis/dropify

'use strict';

(function () {

  $('#myDropify').dropify();

})();
